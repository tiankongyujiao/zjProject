import { bar } from "./bar.js";

export function foo() {
  console.log("foo");
  bar()
}
