import { foo } from "./foo.js";
import user from './user.json'



console.log(user)
foo();
console.log("main.js");
