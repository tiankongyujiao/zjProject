<template lang="html">
  <div class="cron" :val="value_">
    <!-- <div style="height: 50px;"> -->
      <a-alert size="small" type="error" message="日期与星期不可以同时为“不指定”" v-if="showError" banner />
      <a-alert size="small" type="error" message="日期与星期必须有一个为“不指定”" v-if="showError2" banner />
    <!-- </div> -->
    
    <el-tabs v-model="activeName">
      <el-tab-pane label="秒" name="s">
        <second-and-minute @setCron="setCron" v-model="sVal" lable="秒"></second-and-minute >
      </el-tab-pane>
      <el-tab-pane label="分" name="m">
        <second-and-minute @setCron="setCron" v-model="mVal" lable="分"></second-and-minute >
      </el-tab-pane>
      <el-tab-pane label="时" name="h">
        <hour v-model="hVal" @setCron="setCron" lable="时"></hour>
      </el-tab-pane>
      <el-tab-pane label="日" name="d">
        <day v-model="dVal" @setCron="setCron" lable="日"></day>
      </el-tab-pane>
      <el-tab-pane label="月" name="month">
        <month v-model="monthVal" @setCron="setCron" lable="月"></month>
      </el-tab-pane>
      <el-tab-pane label="周" name="week">
        <week v-model="weekVal" @setCron="setCron" lable="周"></week>
      </el-tab-pane>
      <el-tab-pane label="年" name="year">
        <year v-model="yearVal" @setCron="setCron" lable="年"></year>
      </el-tab-pane>
    </el-tabs>
    <!-- table -->
    <el-table
      :data="tableData"
      size="mini"
      border
      style="width: 100%;">
      <el-table-column
        prop="sVal"
        label="秒"
        width="70">
      </el-table-column>
      <el-table-column
        prop="mVal"
        label="分"
        width="70">
      </el-table-column>
      <el-table-column
        prop="hVal"
        label="时"
        width="70">
      </el-table-column>
      <el-table-column
        prop="dVal"
        label="日"
        width="70">
      </el-table-column>
      <el-table-column
        prop="monthVal"
        label="月"
        width="70">
      </el-table-column>
      <el-table-column
        prop="weekVal"
        label="周"
        width="70">
      </el-table-column>
      <el-table-column
        prop="yearVal"
        label="年">
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import Vue from 'vue'
import { Tabs, TabPane, Table, TableColumn, Radio, InputNumber, Checkbox, CheckboxGroup } from 'element-ui'
import 'element-ui/lib/theme-chalk/index.css'
import SecondAndMinute from './modal/secondAndMinute'
import hour from './modal/hour'
import day from './modal/day'
import month from './modal/month'
import week from './modal/week'
import year from './modal/year'
Vue.use(Tabs)
Vue.use(TabPane)
Vue.use(Table)
Vue.use(TableColumn)
Vue.use(Radio)
Vue.use(InputNumber)
Vue.use(Checkbox)
Vue.use(CheckboxGroup)
export default {
  props: {
    value: {
      type: String,
      default: ''
    }
  },
  data () {
    return {
      //
      showError: false,
      showError2: false,
      activeName: 's',
      sVal: '',
      mVal: '',
      hVal: '',
      dVal: '',
      monthVal: '',
      weekVal: '',
      yearVal: ''
    }
  },
  watch: {
    'value' (a, b) {
      this.updateVal()
    }
  },
  computed: {
    tableData () {
      return [{
        sVal: this.sVal,
        mVal: this.mVal,
        hVal: this.hVal,
        dVal: this.dVal,
        monthVal: this.monthVal,
        weekVal: this.weekVal,
        yearVal: this.yearVal
      }]
    },
    value_ () {
      if (!this.dVal && !this.weekVal) {
        return ''
      }
      if (this.dVal === '?' && this.weekVal === '?') {
        // this.$message.success('日期与星期不可以同时为“不指定”')
        this.showError = true
      } else {
        this.showError = false
      }
      if (this.dVal !== '?' && this.weekVal !== '?') {
        this.showError2 = true
        // this.$message.success('日期与星期必须有一个为“不指定”')
      } else {
        this.showError2 = false
      }
      const v = `${this.sVal} ${this.mVal} ${this.hVal} ${this.dVal} ${this.monthVal} ${this.weekVal} ${this.yearVal}`
      if (v !== this.value) {
        this.$emit('input', v)
      }
      return v
    }
  },
  methods: {
    updateVal () {
      if (!this.value) {
        return
      }
      const arrays = this.value.split(' ')
      this.sVal = arrays[0]
      this.mVal = arrays[1]
      this.hVal = arrays[2]
      this.dVal = arrays[3]
      this.monthVal = arrays[4]
      this.weekVal = arrays[5]
      this.yearVal = arrays[6]
    },
    setCron () {
      this.$emit('setCron')
    }
  },
  created () {
    this.updateVal()
  },
  components: {
    SecondAndMinute, hour, day, month, week, year
  }
}
</script>

<style lang="css">
.cron {
  text-align: left;
  padding: 10px;
  background: #fff;
  border: 1px solid #dcdfe6;
  box-shadow: 0 2px 4px 0 rgba(0,0,0,.12), 0 0 6px 0 rgba(0,0,0,.04);
}
label.el-checkbox {
    margin-right: 0;
}
</style>
